package com.spoiledseed;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Server -> client effects: fog strength, jumpscare overlay, ending text. */
public class PacketNull implements IMessage {
    public static final int FOG = 0;
    public static final int JUMPSCARE = 1;
    public static final int ENDING = 2;

    public int type;
    public float value;

    public PacketNull() {}

    public PacketNull(int type, float value) {
        this.type = type;
        this.value = value;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        type = buf.readInt();
        value = buf.readFloat();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(type);
        buf.writeFloat(value);
    }

    public static class Handler implements IMessageHandler<PacketNull, IMessage> {
        @Override
        public IMessage onMessage(PacketNull m, MessageContext ctx) {
            SpoiledSeed.proxy.handlePacket(m.type, m.value);
            return null;
        }
    }
}
