package com.spoiledseed;

import com.spoiledseed.item.ItemLore;
import com.spoiledseed.item.ItemNullSeal;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModItems {
    public static Item evidence, echoFragment, corruptedCore, forgottenSeal, journalFirst, journalAncient, nullSeal;

    public static void register() {
        evidence = reg(new ItemLore("A shard of dead bark. It is cold, and it does not rot.",
                "Three of these, from three scars in the earth, would tell a story."), "corrupted_evidence");
        echoFragment = reg(new ItemLore("A shard of crystal. If you hold it near your ear, you hear your own footsteps - a moment late."), "echo_fragment");
        corruptedCore = reg(new ItemLore("A black heart that beats once a minute. The fog leans toward it."), "corrupted_core");
        forgottenSeal = reg(new ItemLore("A stone disc worn smooth by hands that no longer exist."), "forgotten_seal");
        journalFirst = reg(new ItemLore(
                "\"It watches from the trees. It never blinks.\"",
                "\"When the fog comes, it is already close. Do not look too long. Do not run until you must.\"",
                "\"I found places where the ground is dead - black sand ringed with moss-stone. Whatever it is, it grows from there. Find three. Bring back what they hide.\""), "journal_first");
        journalAncient = reg(new ItemLore(
                "\"The Seal was made in three parts: an Echo, a voice that would not fade; a Core, the heart of the corruption; and a Seal, the promise of those who bound it.\"",
                "\"Join the three. Bring the result to an Altar. Charge it three times while The Null walks - and do not leave the Altar, or the binding fails.\"",
                "\"It is not a weapon. It is a door, and The Null must be walked through it.\""), "journal_ancient");
        nullSeal = reg(new ItemNullSeal(), "null_seal");
    }

    private static Item reg(Item item, String name) {
        item.setRegistryName(SpoiledSeed.MODID, name);
        item.setUnlocalizedName(name);
        item.setCreativeTab(CreativeTabs.MISC);
        GameRegistry.register(item);
        return item;
    }
}
