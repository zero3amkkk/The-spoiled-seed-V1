package com.spoiledseed;

import com.spoiledseed.director.NullDirector;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

/** Debug/testing command: /spoiledseed ... (op level 2). */
public class CommandSpoiled extends CommandBase {
    @Override
    public String getCommandName() { return "spoiledseed"; }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/spoiledseed <stage <0-5> | event <observe|glimpse|stalk|footsteps|outside|torch|door|theft|bed|jumpscare|chase> | give | reset | status>";
    }

    @Override
    public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        if (args.length == 0) throw new WrongUsageException(getCommandUsage(sender));
        String a = args[0].toLowerCase();
        if (a.equals("stage") && args.length > 1) {
            PlayerData.setStage(p, parseInt(args[1], 0, 5));
            say(p, "Stage set to " + PlayerData.getStage(p));
        } else if (a.equals("event") && args.length > 1) {
            try {
                NullDirector.run(p, NullDirector.rec(p), NullDirector.Ev.valueOf(args[1].toUpperCase()));
            } catch (IllegalArgumentException ex) {
                throw new WrongUsageException(getCommandUsage(sender));
            }
        } else if (a.equals("give")) {
            ItemStack[] all = new ItemStack[] {
                    new ItemStack(ModItems.evidence, 3), new ItemStack(ModItems.echoFragment), new ItemStack(ModItems.corruptedCore),
                    new ItemStack(ModItems.forgottenSeal), new ItemStack(ModItems.journalFirst), new ItemStack(ModItems.journalAncient),
                    new ItemStack(ModBlocks.ancientAltar) };
            for (ItemStack s : all) p.inventory.addItemStackToInventory(s);
            say(p, "Given quest items.");
        } else if (a.equals("reset")) {
            PlayerData.setStage(p, 0);
            PlayerData.setSealed(p, false);
            say(p, "Progress reset (play time kept).");
        } else if (a.equals("status")) {
            say(p, "stage=" + PlayerData.getStage(p) + " seconds=" + PlayerData.getSeconds(p) + " sealed=" + PlayerData.isSealed(p));
        } else {
            throw new WrongUsageException(getCommandUsage(sender));
        }
    }

    private static void say(EntityPlayerMP p, String s) {
        p.addChatMessage(new TextComponentString(s));
    }
}
