package com.spoiledseed.entity;

import com.spoiledseed.Config;
import com.spoiledseed.ModSounds;
import com.spoiledseed.PlayerData;
import com.spoiledseed.director.NullDirector;
import java.util.UUID;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * THE NULL. All gameplay logic runs server-side in updateAITasks(); the client only reads the
 * synced STATE parameter. The entity is never saved meaningfully: without an owner it removes itself.
 */
public class EntityNull extends EntityCreature {
    private static final DataParameter<Integer> STATE = EntityDataManager.<Integer>createKey(EntityNull.class, DataSerializers.VARINT);

    private UUID ownerId;
    private int stateTicks, lifeTicks, maxLife = 600, lookedTicks, attackCooldown, searchTicks, chaseTicksLeft;
    private float escalateChance;
    private boolean ritual;
    private BlockPos lastKnown;

    public EntityNull(World world) {
        super(world);
        this.setSize(0.6F, 1.8F);
        this.isImmuneToFire = true;
        this.tasks.addTask(0, new EntityAISwimming(this));
        ((PathNavigateGround) this.getNavigator()).setCanSwim(true);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(STATE, Integer.valueOf(0));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.23D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }

    public NullState getState() {
        return NullState.byId(this.dataManager.get(STATE).intValue());
    }

    public void setState(NullState s) {
        this.dataManager.set(STATE, Integer.valueOf(s.ordinal()));
        this.stateTicks = 0;
        this.lookedTicks = 0;
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(s == NullState.CHASE ? Config.chaseSpeed : 0.23D);
        if (s == NullState.CHASE) {
            this.chaseTicksLeft = (int) (Config.chaseDurationSeconds * 20 * (0.8D + this.rand.nextDouble() * 0.4D));
            this.searchTicks = 0;
        }
    }

    /** Called once by the director right after construction (server side). */
    public void init(EntityPlayer owner, NullState state, int maxLifeTicks, boolean ritualMode, float escalate) {
        this.ownerId = owner.getUniqueID();
        this.maxLife = maxLifeTicks;
        this.ritual = ritualMode;
        this.escalateChance = escalate;
        this.getAttributeMap().getAttributeInstance(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(Config.chaseDamage);
        this.setState(state);
        this.faceEntity(owner, 360.0F, 360.0F);
        this.rotationYawHead = this.rotationYaw;
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        if (this.worldObj.isRemote) return;

        EntityPlayer p = this.ownerId == null ? null : this.worldObj.getPlayerEntityByUUID(this.ownerId);
        if (p == null || p.isDead) {
            this.setDead();
            return;
        }
        this.stateTicks++;
        this.lifeTicks++;
        if (this.attackCooldown > 0) this.attackCooldown--;

        NullState st = this.getState();
        if (st != NullState.VANISHING && PlayerData.isSealed(p)) {
            this.vanish();
            return;
        }
        switch (st) {
            case OBSERVING:
                this.tickObserving(p);
                break;
            case STALKING:
                this.tickStalking(p);
                break;
            case DISTURBANCE:
                this.tickDisturbance(p);
                break;
            case JUMPSCARE:
                this.getNavigator().clearPathEntity();
                this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
                if (this.stateTicks > 28) this.vanish();
                break;
            case CHASE:
                this.tickChase(p);
                break;
            case VANISHING:
                this.getNavigator().clearPathEntity();
                if (this.stateTicks % 2 == 0) this.darkParticles(4);
                if (this.stateTicks >= 12) this.setDead();
                break;
        }
    }

    // ---- STATE 1: OBSERVING -------------------------------------------------------------
    private void tickObserving(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.getDistanceToEntity(p) < 9.0F) { this.vanish(); return; }      // player approached
        if (this.isLookedAt(p)) this.lookedTicks++; else this.lookedTicks = Math.max(0, this.lookedTicks - 1);
        if (this.lookedTicks > 50) { this.vanish(); return; }                    // watched for too long
        if (this.lifeTicks > this.maxLife) this.vanish();
    }

    // ---- STATE 2: STALKING --------------------------------------------------------------
    private void tickStalking(EntityPlayer p) {
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        double d = this.getDistanceToEntity(p);
        if (this.isLookedAt(p)) {
            this.lookedTicks++;
            this.getNavigator().clearPathEntity();
            if (this.lookedTicks > 25) { this.vanish(); return; }                // seen: appear briefly, then gone
        } else {
            this.lookedTicks = 0;
            if (d > 11.0D) {
                if (this.ticksExisted % 10 == 0) this.getNavigator().tryMoveToEntityLiving(p, 0.8D);   // closer while not watched
            } else {
                this.getNavigator().clearPathEntity();
            }
        }
        if (d < 6.0D) { this.vanish(); return; }
        if (this.lifeTicks > this.maxLife) {
            if (this.rand.nextFloat() < this.escalateChance) this.setState(NullState.CHASE); else this.vanish();
        }
    }

    // ---- STATE 3: DISTURBANCE (director performs the world interactions) ------------------
    private void tickDisturbance(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.lifeTicks > this.maxLife || this.getDistanceToEntity(p) < 6.0F) this.vanish();
    }

    // ---- STATE 5: CHASE -----------------------------------------------------------------
    private void tickChase(EntityPlayer p) {
        double d = this.getDistanceToEntity(p);
        boolean sees = this.canEntityBeSeen(p);
        if (sees) {
            this.lastKnown = new BlockPos(p);
            this.searchTicks = 0;
            this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
            if (this.ticksExisted % 8 == 0) this.getNavigator().tryMoveToEntityLiving(p, 1.0D);
        } else if (this.lastKnown != null) {
            if (this.ticksExisted % 10 == 0) {
                this.getNavigator().tryMoveToXYZ(this.lastKnown.getX() + 0.5D, this.lastKnown.getY(), this.lastKnown.getZ() + 0.5D, 1.0D);
            }
            if (this.getDistanceSq(this.lastKnown) < 6.0D) this.searchTicks++;   // searching last known position
        } else {
            this.searchTicks++;
        }
        if (this.searchTicks > 120 && !this.ritual) { this.vanish(); return; }   // lost the player

        if (sees && d < 1.9D && this.attackCooldown <= 0) {
            this.swingArm(EnumHand.MAIN_HAND);
            float dmg = (float) this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            p.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
            this.attackCooldown = 20;
        }
        if (this.ticksExisted % 12 == 0) {
            this.playSound(ModSounds.CHASE, 1.0F, 0.85F + this.rand.nextFloat() * 0.3F);
        }
        if (!this.ritual) {
            this.chaseTicksLeft--;
            if (this.chaseTicksLeft <= 0 || d > 56.0D) {
                NullDirector.onChaseSurvived(p);
                this.vanish();
            }
        }
    }

    // ---- STATE 6: VANISHING -------------------------------------------------------------
    public void vanish() {
        if (this.worldObj.isRemote || this.getState() == NullState.VANISHING) return;
        this.setState(NullState.VANISHING);
        this.getNavigator().clearPathEntity();
        this.playSound(ModSounds.VANISH, 1.0F, 1.0F);
        this.darkParticles(25);
    }

    /** Final sealing: same as vanish but ritual lock removed first. */
    public void sealAway() {
        this.ritual = false;
        this.vanish();
        this.darkParticles(60);
    }

    private void darkParticles(int n) {
        if (this.worldObj instanceof WorldServer) {
            ((WorldServer) this.worldObj).spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX, this.posY + 1.0D, this.posZ, n, 0.3D, 0.8D, 0.3D, 0.02D);
        }
    }

    private boolean isLookedAt(EntityPlayer p) {
        Vec3d look = p.getLook(1.0F).normalize();
        Vec3d to = new Vec3d(this.posX - p.posX, (this.posY + this.getEyeHeight()) - (p.posY + p.getEyeHeight()), this.posZ - p.posZ);
        if (to.lengthVector() < 0.001D) return true;
        return look.dotProduct(to.normalize()) > 0.93D && p.canEntityBeSeen(this);
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (src == DamageSource.outOfWorld) return super.attackEntityFrom(src, amount);
        NullState st = this.getState();
        if (!this.worldObj.isRemote && src.getEntity() instanceof EntityPlayer && (st == NullState.OBSERVING || st == NullState.STALKING || st == NullState.DISTURBANCE)) {
            this.vanish();      // it cannot be killed - it just leaves
        }
        return false;
    }
}
