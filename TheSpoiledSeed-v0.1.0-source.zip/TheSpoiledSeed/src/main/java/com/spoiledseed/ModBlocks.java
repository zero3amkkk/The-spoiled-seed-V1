package com.spoiledseed;

import com.spoiledseed.block.BlockAltar;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModBlocks {
    public static Block ancientAltar;

    public static void register() {
        ancientAltar = new BlockAltar();
        ancientAltar.setRegistryName(SpoiledSeed.MODID, "ancient_altar");
        ancientAltar.setUnlocalizedName("ancient_altar");
        ancientAltar.setCreativeTab(CreativeTabs.MISC);
        GameRegistry.register(ancientAltar);
        ItemBlock ib = new ItemBlock(ancientAltar);
        ib.setRegistryName(ancientAltar.getRegistryName());
        GameRegistry.register(ib);
    }
}
