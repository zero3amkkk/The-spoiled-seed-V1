package com.spoiledseed;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static SimpleNetworkWrapper CHANNEL;

    public static void init() {
        CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel(SpoiledSeed.MODID);
        CHANNEL.registerMessage(PacketNull.Handler.class, PacketNull.class, 0, Side.CLIENT);
    }
}
