package com.spoiledseed.world;

import com.spoiledseed.Config;
import com.spoiledseed.ModBlocks;
import com.spoiledseed.ModItems;
import java.util.Random;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.fml.common.IWorldGenerator;

/**
 * Small corrupted structures (each holds one quest item in a chest):
 *  - Corrupted Site (soul sand)  : Corrupted Evidence       (Quest 2)
 *  - Echo Shrine (obsidian)      : Echo Fragment            (Quest 4)
 *  - Core Cairn (netherrack)     : Corrupted Core           (Quest 4)
 *  - Forgotten Ruin (mossy)      : Ancient Journal + Forgotten Seal + Ancient Altar, in a chamber
 *                                  reached by a ladder shaft from the surface (Quests 3, 4, 5)
 */
public class WorldGenSites implements IWorldGenerator {
    @Override
    public void generate(Random rand, int chunkX, int chunkZ, World world, IChunkGenerator gen, IChunkProvider prov) {
        if (world.provider.getDimension() != 0 || Config.siteRarity <= 0) return;
        if (rand.nextInt(Config.siteRarity) != 0) return;

        int x = chunkX * 16 + 8 + rand.nextInt(4);
        int z = chunkZ * 16 + 8 + rand.nextInt(4);
        BlockPos g = world.getHeight(new BlockPos(x, 0, z));
        while (g.getY() > 2 && (world.isAirBlock(g.down()) || isFoliage(world.getBlockState(g.down())))) g = g.down();
        if (!world.getBlockState(g.down()).getMaterial().isSolid()) return;     // no water / lava spots

        int roll = rand.nextInt(100);
        if (roll < 55) {
            platform(world, g, Blocks.SOUL_SAND.getDefaultState(), Blocks.MOSSY_COBBLESTONE.getDefaultState(),
                    new ItemStack(ModItems.evidence), null, rand);
        } else if (roll < 70) {
            platform(world, g, Blocks.OBSIDIAN.getDefaultState(), Blocks.STONEBRICK.getDefaultState(),
                    new ItemStack(ModItems.echoFragment), null, rand);
        } else if (roll < 85) {
            platform(world, g, Blocks.NETHERRACK.getDefaultState(), Blocks.COBBLESTONE.getDefaultState(),
                    new ItemStack(ModItems.corruptedCore), null, rand);
        } else if (g.getY() > 32) {
            ruin(world, g, rand);
        }
    }

    private static boolean isFoliage(IBlockState s) {
        Material m = s.getMaterial();
        return m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE;
    }

    private static void fill(World w, BlockPos chest, ItemStack a, ItemStack b, Random rand) {
        TileEntity te = w.getTileEntity(chest);
        if (te instanceof TileEntityChest) {
            TileEntityChest c = (TileEntityChest) te;
            if (a != null) c.setInventorySlotContents(10 + rand.nextInt(4), a);
            if (b != null) c.setInventorySlotContents(14 + rand.nextInt(4), b);
        }
    }

    /** 5x5 floor, four pillars, a chest in the middle, clear sky above. */
    private static BlockPos platform(World w, BlockPos g, IBlockState floor, IBlockState pillar, ItemStack a, ItemStack b, Random rand) {
        IBlockState air = Blocks.AIR.getDefaultState();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                w.setBlockState(g.add(dx, -1, dz), floor, 2);
                for (int dy = 0; dy < 5; dy++) w.setBlockState(g.add(dx, dy, dz), air, 2);
            }
        }
        for (int sx = -2; sx <= 2; sx += 4)
            for (int sz = -2; sz <= 2; sz += 4)
                for (int dy = 0; dy < 3; dy++) w.setBlockState(g.add(sx, dy, sz), pillar, 2);
        w.setBlockState(g, Blocks.CHEST.getDefaultState(), 2);
        fill(w, g, a, b, rand);
        return g;
    }

    private static void ruin(World w, BlockPos g, Random rand) {
        IBlockState brick = Blocks.STONEBRICK.getDefaultState();
        IBlockState air = Blocks.AIR.getDefaultState();
        IBlockState ladder = Blocks.LADDER.getDefaultState().withProperty(BlockLadder.FACING, EnumFacing.NORTH);
        int y0 = 22;

        // surface marker (mossy floor + pillars); the centre block is plain on purpose - the loot is below
        platform(w, g, Blocks.MOSSY_COBBLESTONE.getDefaultState(), Blocks.MOSSY_COBBLESTONE.getDefaultState(), null, null, rand);
        w.setBlockState(g, Blocks.MOSSY_COBBLESTONE.getDefaultState(), 2);

        // chamber 7x4x7: stone-brick shell, hollow inside
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = 0; dy <= 4; dy++) {
                    boolean edge = dx == -3 || dx == 3 || dz == -3 || dz == 3 || dy == 0 || dy == 4;
                    w.setBlockState(new BlockPos(g.getX() + dx, y0 + dy, g.getZ() + dz), edge ? brick : air, 2);
                }
            }
        }
        // ladder shaft at (0,+2): ladders face NORTH and hang on the brick wall at z+3
        int lx = g.getX(), lz = g.getZ() + 2;
        for (int y = y0 + 1; y <= g.getY() - 1; y++) {
            w.setBlockState(new BlockPos(lx, y, lz), ladder, 2);
            w.setBlockState(new BlockPos(lx, y, lz + 1), brick, 2);
        }

        // contents
        BlockPos chest = new BlockPos(g.getX() - 2, y0 + 1, g.getZ() - 2);
        w.setBlockState(chest, Blocks.CHEST.getDefaultState(), 2);
        fill(w, chest, new ItemStack(ModItems.journalAncient), new ItemStack(ModItems.forgottenSeal), rand);
        w.setBlockState(new BlockPos(g.getX(), y0 + 1, g.getZ() - 1), ModBlocks.ancientAltar.getDefaultState(), 2);
        w.setBlockState(new BlockPos(g.getX() + 2, y0 + 1, g.getZ() - 2), Blocks.TORCH.getDefaultState(), 2);
        w.setBlockState(new BlockPos(g.getX() - 2, y0 + 1, g.getZ() + 2), Blocks.TORCH.getDefaultState(), 2);
    }
}
