package com.spoiledseed.client;

import com.spoiledseed.PacketNull;
import com.spoiledseed.SpoiledSeed;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Client-only visuals: Black Fog (cheap GL fog, no shaders), jumpscare overlay, ending text. */
public class ClientEvents {
    public static final ClientEvents INSTANCE = new ClientEvents();
    private static final ResourceLocation SKIN = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null.png");
    private static final int JUMP_LEN = 22;

    private float fogTarget, fogCurrent;
    private int jumpTicks;
    private int endTick = -1;

    public void handle(int type, float value) {
        if (type == PacketNull.FOG) fogTarget = value;
        else if (type == PacketNull.JUMPSCARE) jumpTicks = JUMP_LEN;
        else if (type == PacketNull.ENDING) endTick = 0;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) {            // left the world: reset everything
            fogTarget = 0F; fogCurrent = 0F; jumpTicks = 0; endTick = -1;
            return;
        }
        fogCurrent += (fogTarget - fogCurrent) * 0.04F;
        if (Math.abs(fogTarget - fogCurrent) < 0.002F) fogCurrent = fogTarget;
        if (jumpTicks > 0) jumpTicks--;
        if (endTick >= 0 && ++endTick > 520) endTick = -1;
    }

    // ---- Black Fog ----
    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.RenderFogEvent e) {
        if (fogCurrent <= 0.01F) return;
        float far = e.getFarPlaneDistance();
        float end = Math.max(6F, far * (1F - 0.88F * fogCurrent));
        GlStateManager.setFog(GlStateManager.FogMode.LINEAR);
        GlStateManager.setFogStart(end * 0.05F);
        GlStateManager.setFogEnd(end);
    }

    @SubscribeEvent
    public void onFogColor(EntityViewRenderEvent.FogColors e) {
        if (fogCurrent <= 0.01F) return;
        float k = 1F - 0.92F * fogCurrent;
        e.setRed(e.getRed() * k);
        e.setGreen(e.getGreen() * k);
        e.setBlue(e.getBlue() * k);
    }

    // ---- Jumpscare + ending ----
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        ScaledResolution sr = e.getResolution();
        int w = sr.getScaledWidth(), h = sr.getScaledHeight();

        if (jumpTicks > 0) {
            float t = jumpTicks / (float) JUMP_LEN;
            int a = (int) (255 * Math.min(1F, t * 3F));
            Gui.drawRect(0, 0, w, h, (a << 24) | 0x101014);
            GlStateManager.color(1F, 1F, 1F, 1F);
            mc.getTextureManager().bindTexture(SKIN);
            int s = h;                                     // head face = pixels (8,8) 8x8 of the 64x64 skin
            Gui.drawScaledCustomSizeModalRect((w - s) / 2, 0, 8F, 8F, 8, 8, s, s, 64F, 64F);
        }
        if (endTick >= 0) {
            drawCentered(mc, "THE WORLD IS QUIET AGAIN.", w, h, fade(endTick, 30, 200));
            drawCentered(mc, "BUT SOMETHING REMAINS...", w, h, fade(endTick, 300, 480));
        }
    }

    private static float fade(int t, int start, int end) {
        float in = Math.min(1F, (t - start) / 30F);
        float out = Math.min(1F, (end - t) / 30F);
        return Math.max(0F, Math.min(in, out));
    }

    private static void drawCentered(Minecraft mc, String s, int w, int h, float alpha) {
        int a = (int) (255 * alpha);
        if (a < 8) return;
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.translate(w / 2F, h / 2F, 0F);
        GlStateManager.scale(2.5F, 2.5F, 1F);
        mc.fontRendererObj.drawStringWithShadow(s, -mc.fontRendererObj.getStringWidth(s) / 2F, -4F, (a << 24) | 0xE0E0E0);
        GlStateManager.popMatrix();
    }
}
