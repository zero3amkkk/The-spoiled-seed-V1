package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.entity.EntityNull;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Renders The Null with the supplied 64x64 skin on a player-proportioned model. */
public class RenderNull extends RenderLiving<EntityNull> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null.png");

    // second argument: true = slim (Alex, 3px) arms, false = classic (Steve, 4px) arms.
    public RenderNull(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, false), 0.0F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityNull entity) {
        return TEXTURE;
    }
}
