package com.spoiledseed;

import com.spoiledseed.director.NullDirector;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.proxy.CommonProxy;
import com.spoiledseed.world.WorldGenSites;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = SpoiledSeed.MODID, name = "The Spoiled Seed", version = SpoiledSeed.VERSION, acceptedMinecraftVersions = "[1.9.4]")
public class SpoiledSeed {
    public static final String MODID = "spoiledseed";
    public static final String VERSION = "0.1.0";

    @Mod.Instance(MODID)
    public static SpoiledSeed instance;

    @SidedProxy(clientSide = "com.spoiledseed.proxy.ClientProxy", serverSide = "com.spoiledseed.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        Config.load(e.getSuggestedConfigurationFile());
        ModSounds.register();
        ModItems.register();
        ModBlocks.register();
        NetworkHandler.init();
        EntityRegistry.registerModEntity(EntityNull.class, "the_null", 0, this, 64, 3, true);
        MinecraftForge.EVENT_BUS.register(new NullDirector());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ModRecipes.register();
        GameRegistry.registerWorldGenerator(new WorldGenSites(), 0);
        proxy.init();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        NullDirector.reset();
        e.registerServerCommand(new CommandSpoiled());
    }

    @Mod.EventHandler
    public void serverStopping(FMLServerStoppingEvent e) {
        NullDirector.relightAll();
        NullDirector.reset();
    }
}
