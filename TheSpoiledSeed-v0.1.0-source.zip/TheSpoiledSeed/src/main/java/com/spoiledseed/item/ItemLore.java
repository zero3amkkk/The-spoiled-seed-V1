package com.spoiledseed.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

/** Quest item that prints its lore in chat when right-clicked. */
public class ItemLore extends Item {
    private final String[] lines;

    public ItemLore(String... lines) {
        this.lines = lines;
        this.setMaxStackSize(16);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(ItemStack stack, World world, EntityPlayer player, EnumHand hand) {
        if (!world.isRemote) {
            for (String l : lines) {
                player.addChatMessage(new TextComponentString(TextFormatting.GRAY + "" + TextFormatting.ITALIC + l));
            }
        }
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }
}
