package com.spoiledseed.proxy;

import com.spoiledseed.ModBlocks;
import com.spoiledseed.ModItems;
import com.spoiledseed.client.ClientEvents;
import com.spoiledseed.client.RenderNull;
import com.spoiledseed.entity.EntityNull;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityNull.class, new IRenderFactory<EntityNull>() {
            @Override
            public Render<? super EntityNull> createRenderFor(RenderManager manager) {
                return new RenderNull(manager);
            }
        });
        model(ModItems.evidence);
        model(ModItems.echoFragment);
        model(ModItems.corruptedCore);
        model(ModItems.forgottenSeal);
        model(ModItems.journalFirst);
        model(ModItems.journalAncient);
        model(ModItems.nullSeal);
        model(Item.getItemFromBlock(ModBlocks.ancientAltar));
        MinecraftForge.EVENT_BUS.register(ClientEvents.INSTANCE);
    }

    private static void model(Item item) {
        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }

    @Override
    public void handlePacket(final int type, final float value) {
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override
            public void run() {
                ClientEvents.INSTANCE.handle(type, value);
            }
        });
    }
}
