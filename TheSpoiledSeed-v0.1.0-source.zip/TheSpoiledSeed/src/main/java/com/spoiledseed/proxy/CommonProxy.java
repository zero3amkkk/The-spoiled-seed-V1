package com.spoiledseed.proxy;

public class CommonProxy {
    public void preInit() {}
    public void init() {}
    /** Server-bound builds never receive these; the client proxy overrides it. */
    public void handlePacket(int type, float value) {}
}
