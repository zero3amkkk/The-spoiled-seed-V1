package com.spoiledseed;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModSounds {
    public static SoundEvent FOOTSTEP, JUMPSCARE, VANISH, CHASE, AMBIENT, SEAL;

    public static void register() {
        FOOTSTEP = make("null_footstep");
        JUMPSCARE = make("null_jumpscare");
        VANISH = make("null_vanish");
        CHASE = make("null_chase");
        AMBIENT = make("null_ambient");
        SEAL = make("seal_activate");
    }

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(SpoiledSeed.MODID, name);
        SoundEvent s = new SoundEvent(rl);
        s.setRegistryName(rl);
        GameRegistry.register(s);
        return s;
    }
}
