package com.spoiledseed;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public class Config {
    public static int graceSeconds = 600;
    public static int eventIntervalSeconds = 180;
    public static float eventProbability = 0.7F;
    public static int chaseDurationSeconds = 25;
    public static float chaseSpeed = 0.31F;
    public static float chaseDamage = 3.0F;
    public static int jumpscareCooldownSeconds = 300;
    public static boolean fogEnabled = true;
    public static float fogBeforeEncounterChance = 0.4F;
    public static boolean theftEnabled = true;
    public static boolean affectCreative = false;
    public static int siteRarity = 25;

    public static void load(File file) {
        Configuration c = new Configuration(file);
        String t = "timing";
        graceSeconds = c.getInt("graceSeconds", t, graceSeconds, 0, 1000000, "Seconds of play before any horror event can happen (counted per player).");
        eventIntervalSeconds = c.getInt("eventIntervalSeconds", t, eventIntervalSeconds, 20, 100000, "Base seconds between events. Shrinks as the story progresses.");
        jumpscareCooldownSeconds = c.getInt("jumpscareCooldownSeconds", t, jumpscareCooldownSeconds, 10, 100000, "Minimum seconds between jumpscares.");
        String g = "gameplay";
        eventProbability = c.getFloat("eventProbability", g, eventProbability, 0F, 1F, "Chance that an event actually fires when the timer expires.");
        chaseDurationSeconds = c.getInt("chaseDurationSeconds", g, chaseDurationSeconds, 5, 600, "Average chase length in seconds.");
        chaseSpeed = c.getFloat("chaseSpeed", g, chaseSpeed, 0.1F, 0.6F, "Movement speed attribute of The Null while chasing.");
        chaseDamage = c.getFloat("chaseDamage", g, chaseDamage, 0F, 20F, "Damage per hit (2.0 = one heart).");
        theftEnabled = c.getBoolean("theftEnabled", g, theftEnabled, "Allow The Null to hide small amounts of ordinary items.");
        affectCreative = c.getBoolean("affectCreative", g, affectCreative, "Run horror events on creative/spectator players (testing).");
        String f = "fog";
        fogEnabled = c.getBoolean("fogEnabled", f, fogEnabled, "Enable the Black Fog.");
        fogBeforeEncounterChance = c.getFloat("fogBeforeEncounterChance", f, fogBeforeEncounterChance, 0F, 1F, "Chance that fog rolls in a few seconds before an encounter.");
        String w = "world";
        siteRarity = c.getInt("siteRarity", w, siteRarity, 0, 100000, "1 in N chunks gets a corrupted structure. 0 disables generation.");
        if (c.hasChanged()) c.save();
    }
}
