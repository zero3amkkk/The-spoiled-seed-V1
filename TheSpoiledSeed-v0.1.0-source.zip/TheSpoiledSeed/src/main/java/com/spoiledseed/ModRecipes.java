package com.spoiledseed;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModRecipes {
    public static void register() {
        // THE NULL SEAL = Echo Fragment + Corrupted Core + Forgotten Seal (shapeless, crafting table or 2x2 grid)
        GameRegistry.addShapelessRecipe(new ItemStack(ModItems.nullSeal),
                ModItems.echoFragment, ModItems.corruptedCore, ModItems.forgottenSeal);
    }
}
