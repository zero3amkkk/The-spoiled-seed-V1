package com.spoiledseed.director;

import com.spoiledseed.Config;
import com.spoiledseed.ModItems;
import com.spoiledseed.ModSounds;
import com.spoiledseed.NetworkHandler;
import com.spoiledseed.PacketNull;
import com.spoiledseed.PlayerData;
import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockLog;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Server-side "horror director": decides WHEN things happen to each player, according to
 * play time and quest progress. One Null per player at most; events are spaced by a cooldown.
 */
public class NullDirector {
    public enum Ev { OBSERVE, GLIMPSE, STALK, FOOTSTEPS, OUTSIDE, TORCH, DOOR, THEFT, BED, JUMPSCARE, CHASE }

    public static final Random RAND = new Random();

    public static class Rec {
        public UUID nullId;
        public int cooldown = 30;       // seconds until the next event may fire
        public int jumpCd;              // seconds until next jumpscare is allowed
        public float fogBase;           // lingering fog (decays)
        public float lastFog = -1F;     // last value sent to the client
        public Ev pending;              // event delayed behind a fog prelude
        public int pendingDelay;
    }

    private static class Task { int ticks; Runnable r; }
    private static class Relight { WorldServer w; BlockPos pos; IBlockState state; int ticks; }

    private static final Map<UUID, Rec> RECS = new HashMap<UUID, Rec>();
    private static final List<Task> TASKS = new ArrayList<Task>();
    private static final List<Relight> RELIGHTS = new ArrayList<Relight>();

    public static Rec rec(EntityPlayer p) {
        Rec r = RECS.get(p.getUniqueID());
        if (r == null) { r = new Rec(); RECS.put(p.getUniqueID(), r); }
        return r;
    }

    public static void reset() {
        RECS.clear();
        TASKS.clear();
        Ritual.clearAll();
    }

    public static void schedule(int ticks, Runnable r) {
        Task t = new Task();
        t.ticks = ticks;
        t.r = r;
        TASKS.add(t);
    }

    public static void msg(EntityPlayer p, String s) {
        p.addChatMessage(new TextComponentString(TextFormatting.DARK_GRAY + "" + TextFormatting.ITALIC + s));
    }

    // =========================================================================================
    // Forge events
    // =========================================================================================
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        if (!(e.player instanceof EntityPlayerMP)) return;
        if (e.player.ticksExisted % 20 != 0) return;
        try {
            secondTick((EntityPlayerMP) e.player);
        } catch (RuntimeException ex) {
            ex.printStackTrace();      // never let a horror bug crash the server
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (!TASKS.isEmpty()) {
            List<Runnable> run = new ArrayList<Runnable>();
            for (Iterator<Task> it = TASKS.iterator(); it.hasNext();) {
                Task t = it.next();
                if (--t.ticks <= 0) { run.add(t.r); it.remove(); }
            }
            for (Runnable r : run) {
                try { r.run(); } catch (RuntimeException ex) { ex.printStackTrace(); }
            }
        }
        if (!RELIGHTS.isEmpty()) {
            for (Iterator<Relight> it = RELIGHTS.iterator(); it.hasNext();) {
                Relight rl = it.next();
                if (--rl.ticks <= 0) { relight(rl); it.remove(); }
            }
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) {
            Ritual.cancel((EntityPlayerMP) e.player, null);
        }
        RECS.remove(e.player.getUniqueID());
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayerMP) {
            EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
            Ritual.cancel(p, "The altar goes dark.");
            Rec r = RECS.get(p.getUniqueID());
            if (r != null) { r.pending = null; r.cooldown = Math.max(r.cooldown, 60); }
        }
    }

    @SubscribeEvent
    public void onCrafted(PlayerEvent.ItemCraftedEvent e) {
        if (e.crafting != null && e.crafting.getItem() == ModItems.nullSeal && !e.player.worldObj.isRemote) {
            msg(e.player, "The Null Seal is whole. The Ancient Altar is waiting somewhere in the dark.");
        }
    }

    // =========================================================================================
    // Per-player, once per second
    // =========================================================================================
    private void secondTick(EntityPlayerMP p) {
        PlayerData.addSeconds(p, 1);
        if (p.dimension != 0 || p.isDead) return;
        Rec r = rec(p);
        questTick(p);
        if (r.jumpCd > 0) r.jumpCd--;

        if (PlayerData.isSealed(p)) { sendFog(p, r, 0F); return; }
        if (!Config.affectCreative && (p.capabilities.isCreativeMode || p.isSpectator())) { sendFog(p, r, 0F); return; }

        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = findNull(w, r);
        float intensity = intensity(p);

        // ---- Black Fog ----
        float fog = r.fogBase;
        r.fogBase = Math.max(0F, r.fogBase - 0.05F);
        if (n != null) {
            float d = (float) n.getDistanceToEntity(p);
            fog = Math.max(fog, 0.25F + 0.75F * Math.max(0F, 1F - d / 45F));
        } else if (r.nullId != null) {
            r.nullId = null;                                              // it vanished -> cooldown before next appearance
            r.cooldown = Math.max(r.cooldown, nextCooldown(intensity));
        }
        sendFog(p, r, Config.fogEnabled ? fog : 0F);

        if (Ritual.isActive(p)) { Ritual.tick(p, n); return; }
        if (n != null) return;
        if (PlayerData.getSeconds(p) < Config.graceSeconds) return;

        if (r.pending != null) {
            if (--r.pendingDelay <= 0) { Ev e = r.pending; r.pending = null; run(p, r, e); }
            return;
        }
        if (r.cooldown > 0) { r.cooldown--; return; }
        if (RAND.nextFloat() > Config.eventProbability) { r.cooldown = 20 + RAND.nextInt(25); return; }

        Ev ev = pick(p, intensity);
        if (Config.fogEnabled && spawnsNull(ev) && RAND.nextFloat() < Config.fogBeforeEncounterChance) {
            r.pending = ev;                 // fog first, entity a few seconds later
            r.pendingDelay = 8;
            r.fogBase = 1F;
        } else {
            run(p, r, ev);
        }
        r.cooldown = nextCooldown(intensity);
    }

    private static boolean spawnsNull(Ev e) {
        return e == Ev.OBSERVE || e == Ev.GLIMPSE || e == Ev.STALK || e == Ev.BED || e == Ev.CHASE;
    }

    /** 0..1 : grows with play time and quest stage. */
    public static float intensity(EntityPlayer p) {
        float t = Math.min(1F, PlayerData.getSeconds(p) / 7200F);
        return Math.min(1F, 0.1F + PlayerData.getStage(p) * 0.18F + t * 0.3F);
    }

    private static int nextCooldown(float intensity) {
        double base = Config.eventIntervalSeconds * (0.6D + RAND.nextDouble() * 0.8D);
        return (int) (base / (1.0D + 2.0D * intensity)) + 15;
    }

    private static Ev pick(EntityPlayer p, float intensity) {
        int stage = PlayerData.getStage(p);
        if (stage == 0 && PlayerData.getSeconds(p) > Config.graceSeconds + 900) return Ev.CHASE;  // guarantee the first encounter
        int[] w = new int[Ev.values().length];
        w[Ev.OBSERVE.ordinal()] = 5;
        w[Ev.GLIMPSE.ordinal()] = 3;
        w[Ev.FOOTSTEPS.ordinal()] = 3;
        w[Ev.OUTSIDE.ordinal()] = 3;
        w[Ev.TORCH.ordinal()] = 2;
        w[Ev.DOOR.ordinal()] = 2;
        if (stage >= 1) {
            w[Ev.STALK.ordinal()] = 3 + stage;
            w[Ev.BED.ordinal()] = 2;
            w[Ev.THEFT.ordinal()] = Config.theftEnabled ? 2 : 0;
            w[Ev.JUMPSCARE.ordinal()] = 2;
            w[Ev.CHASE.ordinal()] = 2 + stage;
        } else if (intensity > 0.3F) {
            w[Ev.STALK.ordinal()] = 2;
        }
        int total = 0;
        for (int x : w) total += x;
        int roll = RAND.nextInt(total);
        for (int i = 0; i < w.length; i++) {
            roll -= w[i];
            if (roll < 0) return Ev.values()[i];
        }
        return Ev.OBSERVE;
    }

    // =========================================================================================
    // Event execution (also used by /spoiledseed event ...)
    // =========================================================================================
    public static void run(EntityPlayerMP p, Rec r, Ev e) {
        float in = intensity(p);
        switch (e) {
            case OBSERVE:
                spawn(p, r, NullState.OBSERVING, 22, 36, 20 * (25 + RAND.nextInt(30)), false, 0F);
                break;
            case GLIMPSE:
                spawn(p, r, NullState.OBSERVING, 12, 22, 70, false, 0F);
                break;
            case STALK:
                spawn(p, r, NullState.STALKING, 24, 34, 20 * 40, false, 0.2F + 0.4F * in);
                break;
            case FOOTSTEPS:
                footsteps(p);
                break;
            case OUTSIDE:
                outsideSound(p);
                break;
            case TORCH:
                extinguish(p);
                lurk(p, r);
                break;
            case DOOR:
                toggleDoor(p);
                lurk(p, r);
                break;
            case THEFT:
                steal(p);
                lurk(p, r);
                break;
            case BED:
                spawnNearBed(p, r);
                break;
            case JUMPSCARE:
                jumpscare(p, r);
                break;
            case CHASE:
                spawn(p, r, NullState.CHASE, 16, 26, 0, false, 0F);
                break;
        }
    }

    /** DISTURBANCE state: sometimes it stands in the distance while it interferes with the world. */
    private static void lurk(EntityPlayerMP p, Rec r) {
        if (RAND.nextFloat() < 0.5F) spawn(p, r, NullState.DISTURBANCE, 14, 22, 200, false, 0F);
    }

    public static EntityNull findNull(WorldServer w, Rec r) {
        if (r.nullId == null) return null;
        Entity e = w.getEntityFromUuid(r.nullId);
        return (e instanceof EntityNull && !e.isDead) ? (EntityNull) e : null;
    }

    public static EntityNull spawn(EntityPlayerMP p, Rec r, NullState st, int minD, int maxD, int life, boolean ritual, float escalate) {
        if (PlayerData.isSealed(p)) return null;
        WorldServer w = (WorldServer) p.worldObj;
        if (findNull(w, r) != null) return null;                       // never duplicate
        BlockPos pos = findSpot(w, new BlockPos(p), p, minD, maxD, true);
        if (pos == null) return null;
        return spawnAt(p, r, pos, st, life, ritual, escalate);
    }

    private static EntityNull spawnAt(EntityPlayerMP p, Rec r, BlockPos pos, NullState st, int life, boolean ritual, float escalate) {
        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = new EntityNull(w);
        n.setLocationAndAngles(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, RAND.nextFloat() * 360F, 0F);
        n.init(p, st, life, ritual, escalate);
        w.spawnEntityInWorld(n);
        r.nullId = n.getUniqueID();
        return n;
    }

    /** Used by the final ritual: chase with no timeout, spawned on any standing spot near the player. */
    public static EntityNull spawnRitualNull(EntityPlayerMP p) {
        Rec r = rec(p);
        WorldServer w = (WorldServer) p.worldObj;
        if (findNull(w, r) != null) return null;
        BlockPos pos = standingSpotAround(w, new BlockPos(p), 10, 16);
        if (pos == null) pos = standingSpotAround(w, new BlockPos(p), 5, 9);
        if (pos == null) pos = standingSpotAround(w, new BlockPos(p), 2, 4);
        if (pos == null) return null;
        return spawnAt(p, r, pos, NullState.CHASE, 0, true, 0F);
    }

    // ---- spawn position search -----------------------------------------------------------
    /** Surface spot scored for forest / darkness / height, never in front of the camera. */
    public static BlockPos findSpot(WorldServer w, BlockPos c, EntityPlayerMP p, int minD, int maxD, boolean avoidFront) {
        BlockPos best = null;
        int bestScore = -999;
        Vec3d look = p.getLookVec();
        double ll = Math.sqrt(look.xCoord * look.xCoord + look.zCoord * look.zCoord);
        for (int i = 0; i < 14; i++) {
            double ang = RAND.nextDouble() * Math.PI * 2D;
            double dist = minD + RAND.nextDouble() * Math.max(1, maxD - minD);
            double dx = Math.cos(ang) * dist, dz = Math.sin(ang) * dist;
            if (avoidFront && ll > 0.01D) {
                double dot = (dx * look.xCoord + dz * look.zCoord) / (ll * dist);
                if (dot > 0.3D) continue;                              // would be inside the camera's cone
            }
            BlockPos probe = new BlockPos(c.getX() + (int) dx, 64, c.getZ() + (int) dz);
            if (!w.isBlockLoaded(probe)) continue;
            BlockPos g = w.getHeight(probe);
            while (g.getY() > 1 && (w.isAirBlock(g.down()) || isFoliage(w.getBlockState(g.down())))) g = g.down();
            if (!w.getBlockState(g.down()).getMaterial().isSolid()) continue;
            if (!w.isAirBlock(g) || !w.isAirBlock(g.up())) continue;
            int score = 0;
            if (w.getLight(g) < 8) score += 2;
            score += trees(w, g);
            if (g.getY() > p.posY + 2) score += 2;
            if (score > bestScore) { best = g; bestScore = score; }
        }
        return best;
    }

    private static boolean isFoliage(IBlockState s) {
        Material m = s.getMaterial();
        return m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE;
    }

    private static int trees(WorldServer w, BlockPos g) {
        int n = 0;
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                for (int dy = 0; dy <= 3; dy++)
                    if (w.getBlockState(g.add(dx, dy, dz)).getBlock() instanceof BlockLog) n++;
        return Math.min(n, 4);
    }

    /** Any standing spot (2 air blocks above a solid floor) in a ring - works indoors / underground. */
    public static BlockPos standingSpotAround(WorldServer w, BlockPos c, int minD, int maxD) {
        for (int i = 0; i < 30; i++) {
            double ang = RAND.nextDouble() * Math.PI * 2D;
            double dist = minD + RAND.nextDouble() * Math.max(1, maxD - minD);
            int x = c.getX() + (int) (Math.cos(ang) * dist), z = c.getZ() + (int) (Math.sin(ang) * dist);
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos b = new BlockPos(x, c.getY() + dy, z);
                if (!w.isBlockLoaded(b)) break;
                if (w.isAirBlock(b) && w.isAirBlock(b.up()) && w.getBlockState(b.down()).getMaterial().isSolid()) return b;
            }
        }
        return null;
    }

    // ---- individual events ---------------------------------------------------------------
    private static void footsteps(final EntityPlayerMP p) {
        Vec3d look = p.getLookVec();
        double bx = -look.xCoord, bz = -look.zCoord;
        double l = Math.sqrt(bx * bx + bz * bz);
        if (l < 0.01D) { bx = 0D; bz = -1D; l = 1D; }
        final double ux = bx / l, uz = bz / l;
        final WorldServer w = (WorldServer) p.worldObj;
        for (int i = 0; i < 7; i++) {
            final double dist = 9D - i * 1.1D;
            schedule(i * 11 + 1, new Runnable() {
                @Override public void run() {
                    if (p.isDead) return;
                    w.playSound(null, p.posX + ux * dist, p.posY, p.posZ + uz * dist, ModSounds.FOOTSTEP,
                            SoundCategory.HOSTILE, 0.9F, 0.85F + RAND.nextFloat() * 0.3F);
                }
            });
        }
    }

    private static void outsideSound(EntityPlayerMP p) {
        double ang = RAND.nextDouble() * Math.PI * 2D, d = 8D + RAND.nextDouble() * 8D;
        p.worldObj.playSound(null, p.posX + Math.cos(ang) * d, p.posY, p.posZ + Math.sin(ang) * d, ModSounds.AMBIENT,
                SoundCategory.AMBIENT, 1.2F, 0.7F + RAND.nextFloat() * 0.4F);
    }

    private static void extinguish(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> found = new ArrayList<BlockPos>();
        for (int x = -8; x <= 8; x++)
            for (int y = -4; y <= 4; y++)
                for (int z = -8; z <= 8; z++) {
                    BlockPos b = c.add(x, y, z);
                    if (w.getBlockState(b).getBlock() == Blocks.TORCH) found.add(b);
                }
        Collections.shuffle(found, RAND);
        for (int i = 0; i < Math.min(3, found.size()); i++) {
            BlockPos b = found.get(i);
            Relight rl = new Relight();
            rl.w = w; rl.pos = b; rl.state = w.getBlockState(b); rl.ticks = (30 + RAND.nextInt(40)) * 20;
            RELIGHTS.add(rl);
            w.setBlockState(b, Blocks.AIR.getDefaultState());
            w.playSound(null, b.getX() + 0.5D, b.getY() + 0.5D, b.getZ() + 0.5D, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.6F, 1F);
        }
    }

    private static void relight(Relight rl) {
        if (rl.w.isAirBlock(rl.pos) && rl.state.getBlock().canPlaceBlockAt(rl.w, rl.pos)) {
            rl.w.setBlockState(rl.pos, rl.state);
        } else if (rl.w.isAirBlock(rl.pos)) {
            Block.spawnAsEntity(rl.w, rl.pos, new ItemStack(Blocks.TORCH));
        }
    }

    public static void relightAll() {
        for (Relight rl : RELIGHTS) relight(rl);
        RELIGHTS.clear();
    }

    private static void toggleDoor(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> doors = new ArrayList<BlockPos>();
        for (int x = -7; x <= 7; x++)
            for (int y = -2; y <= 2; y++)
                for (int z = -7; z <= 7; z++) {
                    BlockPos b = c.add(x, y, z);
                    IBlockState s = w.getBlockState(b);
                    if (s.getBlock() instanceof BlockDoor && s.getMaterial() == Material.WOOD
                            && s.getValue(BlockDoor.HALF) == BlockDoor.EnumDoorHalf.LOWER) doors.add(b);
                }
        if (doors.isEmpty()) return;
        BlockPos b = doors.get(RAND.nextInt(doors.size()));
        boolean open = BlockDoor.isOpen(w, b);
        ((BlockDoor) w.getBlockState(b).getBlock()).toggleDoor(w, b, !open);
    }

    private static boolean stealable(ItemStack s) {
        if (s == null || s.getMaxStackSize() == 1 || s.isItemStackDamageable() || s.isItemEnchanted() || s.hasDisplayName()) return false;
        Item it = s.getItem();
        if (it.getRegistryName() != null && it.getRegistryName().getResourceDomain().equals(SpoiledSeed.MODID)) return false;
        return it != Items.DIAMOND && it != Items.EMERALD && it != Items.NETHER_STAR;
    }

    private static void steal(EntityPlayerMP p) {
        List<Integer> slots = new ArrayList<Integer>();
        for (int i = 0; i < p.inventory.mainInventory.length; i++) {
            if (stealable(p.inventory.mainInventory[i])) slots.add(Integer.valueOf(i));
        }
        if (slots.isEmpty()) return;
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos spot = findSpot(w, new BlockPos(p), p, 14, 28, false);
        if (spot == null) return;
        int slot = slots.get(RAND.nextInt(slots.size())).intValue();
        ItemStack stack = p.inventory.mainInventory[slot];
        ItemStack taken = stack.splitStack(Math.min(stack.stackSize, 1 + RAND.nextInt(3)));
        if (stack.stackSize <= 0) p.inventory.mainInventory[slot] = null;
        p.inventoryContainer.detectAndSendChanges();

        w.setBlockState(spot, Blocks.CHEST.getDefaultState());       // the hiding place
        TileEntity te = w.getTileEntity(spot);
        if (te instanceof TileEntityChest) ((TileEntityChest) te).setInventorySlotContents(13, taken);
        else Block.spawnAsEntity(w, spot, taken);                    // never destroy the player's items

        double dx = spot.getX() - p.posX, dz = spot.getZ() - p.posZ;
        String dir = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? "east" : "west") : (dz > 0 ? "south" : "north");
        msg(p, "Something took a few of your things. You feel they were left to the " + dir + ", hidden above ground.");
    }

    private static void spawnNearBed(EntityPlayerMP p, Rec r) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos bed = p.getBedLocation();
        BlockPos pos = null;
        if (bed != null && bed.distanceSq(p.posX, p.posY, p.posZ) < 64 * 64) pos = standingSpotAround(w, bed, 4, 7);
        if (pos == null) { spawn(p, r, NullState.OBSERVING, 14, 22, 120, false, 0F); return; }
        if (findNull(w, r) == null) spawnAt(p, r, pos, NullState.OBSERVING, 120, false, 0F);
    }

    private static void jumpscare(EntityPlayerMP p, Rec r) {
        if (r.jumpCd > 0) { run(p, r, Ev.GLIMPSE); return; }          // cooldown: no repeated jumpscares
        r.jumpCd = Config.jumpscareCooldownSeconds + RAND.nextInt(Math.max(1, Config.jumpscareCooldownSeconds / 2));
        WorldServer w = (WorldServer) p.worldObj;
        Vec3d look = p.getLookVec();
        double fx = look.xCoord, fz = look.zCoord, l = Math.sqrt(fx * fx + fz * fz);
        if (l < 0.01D) { fx = 0D; fz = 1D; l = 1D; }
        BlockPos bp = new BlockPos(p.posX + fx / l * 2.6D, p.posY, p.posZ + fz / l * 2.6D);
        if (findNull(w, r) == null && w.isAirBlock(bp) && w.isAirBlock(bp.up())) {
            spawnAt(p, r, bp, NullState.JUMPSCARE, 40, false, 0F);
        }
        w.playSound(null, p.posX, p.posY, p.posZ, ModSounds.JUMPSCARE, SoundCategory.HOSTILE, 1.6F, 1F);
        NetworkHandler.CHANNEL.sendTo(new PacketNull(PacketNull.JUMPSCARE, 0F), p);
        p.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 30, 0, false, false));   // short darkness
        r.fogBase = Math.max(r.fogBase, 0.5F);
    }

    public static void sendFog(EntityPlayerMP p, Rec r, float f) {
        f = Math.max(0F, Math.min(1F, f));
        if (Math.abs(f - r.lastFog) > 0.03F) {
            r.lastFog = f;
            NetworkHandler.CHANNEL.sendTo(new PacketNull(PacketNull.FOG, f), p);
        }
    }

    // =========================================================================================
    // Quests (stage = number of completed main quests)
    // =========================================================================================
    private static int count(EntityPlayerMP p, Item item) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == item) n += s.stackSize;
        return n;
    }

    private static void advance(EntityPlayerMP p, int stage, String text) {
        PlayerData.setStage(p, stage);
        p.addChatMessage(new TextComponentString(TextFormatting.GOLD + "[Quest] " + TextFormatting.GRAY + text));
    }

    private static void questTick(EntityPlayerMP p) {
        switch (PlayerData.getStage(p)) {
            case 1: // Quest 2 - THE BLACK FOG: evidence from three corrupted locations
                if (count(p, ModItems.evidence) >= 3)
                    advance(p, 2, "THE BLACK FOG complete. Three scars, three samples. Something deeper lies beneath the dead ground - a forgotten place.");
                break;
            case 2: // Quest 3 - THE FORGOTTEN PLACE: find the ancient journal underground
                if (count(p, ModItems.journalAncient) >= 1)
                    advance(p, 3, "THE FORGOTTEN PLACE complete. Read the Ancient Journal. Gather the Echo Fragment, the Corrupted Core and the Forgotten Seal.");
                break;
            case 3: // Quest 4 - THE THREE RELICS
                if (count(p, ModItems.echoFragment) >= 1 && count(p, ModItems.corruptedCore) >= 1 && count(p, ModItems.forgottenSeal) >= 1)
                    advance(p, 4, "THE THREE RELICS complete. Combine them into THE NULL SEAL, then find an Ancient Altar.");
                break;
            default:
                break;
        }
    }

    /** Quest 1 - THE FIRST SIGHTING: called by the entity when a chase ended with the player alive. */
    public static void onChaseSurvived(EntityPlayer p) {
        if (!(p instanceof EntityPlayerMP) || PlayerData.getStage(p) != 0) return;
        EntityPlayerMP mp = (EntityPlayerMP) p;
        advance(mp, 1, "THE FIRST SIGHTING complete. You survived. A torn journal lies in your pack - right-click it.");
        ItemStack j = new ItemStack(ModItems.journalFirst);
        if (!mp.inventory.addItemStackToInventory(j)) mp.entityDropItem(j, 0F);
    }
}
